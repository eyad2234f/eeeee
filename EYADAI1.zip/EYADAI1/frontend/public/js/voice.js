// Voice Application Logic
class VoiceApp {
    constructor() {
        this.isRecording = false;
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.speechRecognition = null;
        this.isVoiceMode = false;

        this.init();
    }

    init() {
        this.checkSpeechSupport();
        this.setupEventListeners();
    }

    checkSpeechSupport() {
        // Check for Web Speech API support
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            console.warn('Web Speech API not supported');
            showNotification('متصفحك لا يدعم التعرف على الصوت', 'warning');
            return false;
        }

        // Check for MediaRecorder support
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            console.warn('MediaDevices API not supported');
            showNotification('متصفحك لا يدعم تسجيل الصوت', 'warning');
            return false;
        }

        return true;
    }

    setupEventListeners() {
        // Voice mode toggle
        const voiceBtn = document.getElementById('startVoiceBtn');
        if (voiceBtn) {
            voiceBtn.addEventListener('click', () => {
                this.toggleVoiceRecording();
            });
        }
    }

    toggleVoiceMode() {
        this.isVoiceMode = !this.isVoiceMode;
        const voiceControls = document.getElementById('voiceControls');
        const voiceModal = document.getElementById('voiceModal');

        if (this.isVoiceMode) {
            voiceControls.classList.remove('hidden');
            voiceModal.style.display = 'block';
            showNotification('تم تفعيل الوضع الصوتي', 'success');
        } else {
            voiceControls.classList.add('hidden');
            voiceModal.style.display = 'none';
            this.stopRecording();
            showNotification('تم إيقاف الوضع الصوتي', 'info');
        }
    }

    async toggleVoiceRecording() {
        if (this.isRecording) {
            await this.stopRecording();
        } else {
            await this.startRecording();
        }
    }

    async startRecording() {
        if (!this.checkSpeechSupport()) {
            showNotification('متصفحك لا يدعم التسجيل الصوتي', 'error');
            return;
        }

        try {
            // Request microphone permission
            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    sampleRate: 44100
                }
            });

            // Setup MediaRecorder
            this.mediaRecorder = new MediaRecorder(stream);
            this.audioChunks = [];

            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);
                }
            };

            this.mediaRecorder.onstop = async () => {
                const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
                await this.processAudio(audioBlob);

                // Stop all tracks
                stream.getTracks().forEach(track => track.stop());
            };

            // Start recording
            this.mediaRecorder.start();
            this.isRecording = true;

            // Update UI
            this.updateRecordingUI(true);
            showNotification('جاري التسجيل... تحدث الآن', 'info');

            // Auto-stop after 30 seconds
            setTimeout(() => {
                if (this.isRecording) {
                    this.stopRecording();
                }
            }, 30000);

        } catch (error) {
            console.error('Error starting recording:', error);

            if (error.name === 'NotAllowedError') {
                showNotification('يجب منح الإذن لاستخدام الميكروفون', 'error');
            } else {
                showNotification('فشل بدء التسجيل', 'error');
            }
        }
    }

    async stopRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.isRecording = false;
            this.updateRecordingUI(false);
            showNotification('تم إيقاف التسجيل', 'info');
        }
    }

    async processAudio(audioBlob) {
        try {
            showNotification('جاري معالجة الصوت...', 'info');

            // Convert blob to base64
            const reader = new FileReader();
            reader.readAsDataURL(audioBlob);

            reader.onloadend = async () => {
                const base64Audio = reader.result.split(',')[1];

                // Send to server for speech-to-text
                const response = await fetch('/api/speech/speech-to-text', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        audio: base64Audio,
                        language: document.getElementById('voiceLanguage')?.value || 'ar-EG'
                    })
                });

                const data = await response.json();

                if (data.success && data.text) {
                    // Show transcribed text
                    this.showTranscription(data.text);

                    // Send to chat
                    if (window.chatApp) {
                        document.getElementById('messageInput').value = data.text;
                        await chatApp.sendMessage();
                    }

                } else {
                    throw new Error('Transcription failed');
                }
            };

        } catch (error) {
            console.error('Audio processing error:', error);
            showNotification('فشل تحويل الصوت إلى نص', 'error');
        }
    }

    showTranscription(text) {
        const recordingText = document.getElementById('recordingText');
        if (recordingText) {
            recordingText.innerHTML = `
                <strong>تم التعرف على النص:</strong><br>
                <span style="color: var(--primary-color)">"${text}"</span>
            `;

            // Reset after 5 seconds
            setTimeout(() => {
                recordingText.textContent = 'جاهز للتسجيل...';
            }, 5000);
        }
    }

    updateRecordingUI(isRecording) {
        const startBtn = document.getElementById('startRecordingBtn');
        const voiceBtn = document.getElementById('startVoiceBtn');
        const recordingText = document.getElementById('recordingText');
        const voiceStatus = document.getElementById('voiceStatus');

        if (isRecording) {
            // Update modal
            if (startBtn) {
                startBtn.innerHTML = '<i class="fas fa-stop"></i> إيقاف التسجيل';
                startBtn.classList.remove('btn-primary');
                startBtn.classList.add('btn-danger');
            }

            // Update chat button
            if (voiceBtn) {
                voiceBtn.innerHTML = '<i class="fas fa-stop"></i> إيقاف التسجيل';
                voiceBtn.classList.remove('btn-primary');
                voiceBtn.classList.add('btn-danger');
            }

            // Update status
            if (voiceStatus) {
                voiceStatus.innerHTML = `
                    <i class="fas fa-circle" style="color: #f72585; animation: pulse 1s infinite;"></i>
                    <span>جاري التسجيل...</span>
                `;
            }

            // Update recording text
            if (recordingText) {
                recordingText.textContent = 'جاري التسجيل... تحدث الآن';
                recordingText.style.color = '#f72585';
            }

        } else {
            // Update modal
            if (startBtn) {
                startBtn.innerHTML = '<i class="fas fa-microphone"></i> ابدأ التسجيل';
                startBtn.classList.remove('btn-danger');
                startBtn.classList.add('btn-primary');
            }

            // Update chat button
            if (voiceBtn) {
                voiceBtn.innerHTML = '<i class="fas fa-microphone"></i> تحدث الآن';
                voiceBtn.classList.remove('btn-danger');
                voiceBtn.classList.add('btn-primary');
            }

            // Update status
            if (voiceStatus) {
                voiceStatus.innerHTML = `
                    <i class="fas fa-circle" style="color: #4CAF50;"></i>
                    <span>جاهز للتحدث</span>
                `;
            }

            // Update recording text
            if (recordingText) {
                recordingText.textContent = 'جاهز للتسجيل...';
                recordingText.style.color = 'inherit';
            }
        }
    }

    startVoiceRecording() {
        this.startRecording();
    }

    closeVoiceModal() {
        document.getElementById('voiceModal').style.display = 'none';
        this.stopRecording();
    }

    // Alternative method using Web Speech API (direct browser recognition)
    startSpeechRecognition() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

        if (!SpeechRecognition) {
            showNotification('متصفحك لا يدعم التعرف على الكلام', 'error');
            return;
        }

        this.speechRecognition = new SpeechRecognition();
        this.speechRecognition.continuous = false;
        this.speechRecognition.interimResults = true;
        this.speechRecognition.lang = document.getElementById('voiceLanguage')?.value || 'ar-EG';

        this.speechRecognition.onstart = () => {
            this.isRecording = true;
            this.updateRecordingUI(true);
            showNotification('جاري الاستماع... تحدث الآن', 'info');
        };

        this.speechRecognition.onresult = (event) => {
            const transcript = Array.from(event.results)
                .map(result => result[0].transcript)
                .join('');

            // Update UI with interim results
            const recordingText = document.getElementById('recordingText');
            if (recordingText) {
                recordingText.textContent = transcript || 'جاري التعرف...';
            }

            // If final result, send to chat
            if (event.results[0].isFinal) {
                if (window.chatApp && transcript.trim()) {
                    document.getElementById('messageInput').value = transcript;
                    chatApp.sendMessage();
                }
            }
        };

        this.speechRecognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);

            if (event.error === 'not-allowed') {
                showNotification('يجب منح الإذن لاستخدام الميكروفون', 'error');
            } else if (event.error === 'no-speech') {
                showNotification('لم يتم الكشف عن صوت', 'warning');
            } else {
                showNotification('خطأ في التعرف على الكلام', 'error');
            }

            this.isRecording = false;
            this.updateRecordingUI(false);
        };

        this.speechRecognition.onend = () => {
            this.isRecording = false;
            this.updateRecordingUI(false);
            showNotification('انتهى الاستماع', 'info');
        };

        this.speechRecognition.start();
    }

    stopSpeechRecognition() {
        if (this.speechRecognition) {
            this.speechRecognition.stop();
            this.isRecording = false;
            this.updateRecordingUI(false);
        }
    }
}

// Initialize voice app
const voiceApp = new VoiceApp();

// Global functions for HTML event handlers
function toggleVoiceMode() {
    voiceApp.toggleVoiceMode();
}

function startVoiceRecording() {
    voiceApp.startVoiceRecording();
}

function closeVoiceModal() {
    voiceApp.closeVoiceModal();
}