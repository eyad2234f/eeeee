// Settings Application Logic
class SettingsApp {
    constructor() {
        this.settings = {
            language: 'auto',
            aiLanguage: 'auto',
            autoCorrection: true,
            aiVoice: 'alloy',
            voiceSpeed: '1.0',
            autoPlayVoice: false,
            darkMode: false,
            primaryColor: '#4361ee',
            fontSize: 'medium'
        };

        this.init();
    }

    init() {
        this.loadSettings();
        this.setupEventListeners();
        this.updateUI();
        this.calculateStorage();
    }

    loadSettings() {
        const savedSettings = localStorage.getItem('eyad_settings');

        if (savedSettings) {
            this.settings = { ...this.settings, ...JSON.parse(savedSettings) };
        }

        // Apply settings to UI
        this.applySettingsToUI();
    }

    saveSettings() {
        localStorage.setItem('eyad_settings', JSON.stringify(this.settings));
        this.applySettingsToDOM();
        showNotification('تم حفظ الإعدادات', 'success');
    }

    applySettingsToUI() {
        // Language settings
        document.getElementById('interfaceLanguage').value = this.settings.language;
        document.getElementById('aiLanguage').value = this.settings.aiLanguage;
        document.getElementById('autoCorrection').checked = this.settings.autoCorrection;

        // Voice settings
        document.getElementById('aiVoiceSelect').value = this.settings.aiVoice;
        document.getElementById('voiceSpeed').value = this.settings.voiceSpeed;
        document.getElementById('autoPlayVoice').checked = this.settings.autoPlayVoice;

        // Appearance settings
        document.getElementById('darkModeToggle').checked = this.settings.darkMode;
        document.getElementById('fontSize').value = this.settings.fontSize;

        // Update color picker
        this.updateColorPicker();
    }

    applySettingsToDOM() {
        // Apply dark mode
        if (this.settings.darkMode) {
            document.body.classList.add('dark-mode');
            localStorage.setItem('theme', 'dark');
        } else {
            document.body.classList.remove('dark-mode');
            localStorage.setItem('theme', 'light');
        }

        // Apply primary color
        document.documentElement.style.setProperty('--primary-color', this.settings.primaryColor);

        // Apply font size
        const fontSizeMap = {
            'small': '14px',
            'medium': '16px',
            'large': '18px',
            'xlarge': '20px'
        };
        document.documentElement.style.fontSize = fontSizeMap[this.settings.fontSize] || '16px';

        // Update theme toggle icon
        const themeIcon = document.querySelector('.theme-toggle i');
        if (this.settings.darkMode) {
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
        } else {
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-moon');
        }
    }

    setupEventListeners() {
        // Language settings
        document.getElementById('interfaceLanguage').addEventListener('change', (e) => {
            this.settings.language = e.target.value;
            this.saveSettings();
            this.applyLanguageSettings();
        });

        document.getElementById('aiLanguage').addEventListener('change', (e) => {
            this.settings.aiLanguage = e.target.value;
            this.saveSettings();
        });

        document.getElementById('autoCorrection').addEventListener('change', (e) => {
            this.settings.autoCorrection = e.target.checked;
            this.saveSettings();
        });

        // Voice settings
        document.getElementById('aiVoiceSelect').addEventListener('change', (e) => {
            this.settings.aiVoice = e.target.value;
            this.saveSettings();
        });

        document.getElementById('voiceSpeed').addEventListener('change', (e) => {
            this.settings.voiceSpeed = e.target.value;
            this.saveSettings();
        });

        document.getElementById('autoPlayVoice').addEventListener('change', (e) => {
            this.settings.autoPlayVoice = e.target.checked;
            this.saveSettings();
        });

        // Appearance settings
        document.getElementById('darkModeToggle').addEventListener('change', (e) => {
            this.settings.darkMode = e.target.checked;
            this.saveSettings();
        });

        document.getElementById('fontSize').addEventListener('change', (e) => {
            this.settings.fontSize = e.target.value;
            this.saveSettings();
        });

        // Listen for theme toggle from main.js
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                // Update our settings to match
                this.settings.darkMode = document.body.classList.contains('dark-mode');
                this.saveSettings();
            });
        }
    }

    applyLanguageSettings() {
        const language = this.settings.language;

        if (language === 'auto') {
            const browserLang = navigator.language || 'ar';
            document.documentElement.lang = browserLang.startsWith('ar') ? 'ar' : 'en';
            document.documentElement.dir = browserLang.startsWith('ar') ? 'rtl' : 'ltr';
        } else {
            document.documentElement.lang = language;
            document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
        }

        // Show notification
        if (language === 'ar') {
            showNotification('تم تغيير اللغة إلى العربية', 'success');
        } else if (language === 'en') {
            showNotification('Language changed to English', 'success');
        }
    }

    updateColorPicker() {
        const colorOptions = document.querySelectorAll('.color-option');
        colorOptions.forEach(option => {
            option.classList.remove('active');
            if (option.style.backgroundColor === this.settings.primaryColor) {
                option.classList.add('active');
            }
        });
    }

    setColor(color) {
        this.settings.primaryColor = color;
        this.saveSettings();
        this.updateColorPicker();
    }

    async testVoice() {
        const testText = this.settings.aiLanguage.includes('ar') 
            ? 'مرحباً، هذا اختبار للصوت. أنا Eyad AI مساعدك الذكي.'
            : 'Hello, this is a voice test. I am Eyad AI, your intelligent assistant.';

        const statusElement = document.getElementById('voiceTestStatus');
        statusElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري اختبار الصوت...';

        try {
            const response = await fetch('/api/speech/text-to-speech', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    text: testText,
                    voice: this.settings.aiVoice,
                    language: this.settings.aiLanguage === 'auto' ? 'en' : this.settings.aiLanguage,
                    speed: parseFloat(this.settings.voiceSpeed)
                })
            });

            const data = await response.json();

            if (data.success) {
                statusElement.innerHTML = '<i class="fas fa-volume-up"></i> جاري التشغيل...';

                // Play the audio
                const audio = new Audio(data.fileUrl);
                audio.play();

                audio.onended = () => {
                    statusElement.innerHTML = '<i class="fas fa-check-circle"></i> تم اختبار الصوت بنجاح';
                    setTimeout(() => {
                        statusElement.innerHTML = 'اضغط لاختبار الصوت الحالي';
                    }, 2000);
                };

                audio.onerror = () => {
                    statusElement.innerHTML = '<i class="fas fa-times-circle"></i> فشل تشغيل الصوت';
                };

            } else {
                throw new Error('Voice test failed');
            }

        } catch (error) {
            console.error('Voice test error:', error);
            statusElement.innerHTML = '<i class="fas fa-times-circle"></i> فشل اختبار الصوت';
            setTimeout(() => {
                statusElement.innerHTML = 'اضغط لاختبار الصوت الحالي';
            }, 3000);
        }
    }

    calculateStorage() {
        let totalSize = 0;

        // Calculate localStorage size
        for (let key in localStorage) {
            if (localStorage.hasOwnProperty(key)) {
                totalSize += localStorage[key].length * 2; // UTF-16 characters
            }
        }

        // Convert to readable format
        const formatSize = (bytes) => {
            if (bytes < 1024) return bytes + ' بايت';
            if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' كيلوبايت';
            return (bytes / (1024 * 1024)).toFixed(2) + ' ميجابايت';
        };

        const maxSize = 5 * 1024 * 1024; // 5MB typical localStorage limit
        const percentage = Math.min((totalSize / maxSize) * 100, 100);

        // Update UI
        document.getElementById('storageUsedBar').style.width = percentage + '%';
        document.getElementById('storageInfo').textContent = 
            `${formatSize(totalSize)} مستخدم من ${formatSize(maxSize)}`;

        // Color based on usage
        const bar = document.getElementById('storageUsedBar');
        if (percentage > 90) {
            bar.style.backgroundColor = '#f72585';
        } else if (percentage > 70) {
            bar.style.backgroundColor = '#ff9800';
        } else {
            bar.style.backgroundColor = '#4361ee';
        }
    }

    clearChatHistory() {
        if (confirm('هل تريد مسح جميع سجلات الدردشات؟ لا يمكن التراجع عن هذا الإجراء.')) {
            // Clear conversations from localStorage
            localStorage.removeItem('eyad_conversations');

            // Clear any conversation-related data
            const keysToRemove = [];
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key.startsWith('eyad_chat_') || key.startsWith('eyad_conv_')) {
                    keysToRemove.push(key);
                }
            }

            keysToRemove.forEach(key => localStorage.removeItem(key));

            showNotification('تم مسح جميع سجلات الدردشات', 'success');
            this.calculateStorage();
        }
    }

    clearDocumentsHistory() {
        if (confirm('هل تريد مسح جميع سجلات المستندات؟ لا يمكن التراجع عن هذا الإجراء.')) {
            localStorage.removeItem('eyad_documents_history');
            localStorage.removeItem('eyad_draft_document');

            showNotification('تم مسح جميع سجلات المستندات', 'success');
            this.calculateStorage();
        }
    }

    exportAllData() {
        try {
            const exportData = {};

            // Collect all Eyad AI related data
            for (let key in localStorage) {
                if (localStorage.hasOwnProperty(key) && key.startsWith('eyad_')) {
                    try {
                        exportData[key] = JSON.parse(localStorage[key]);
                    } catch {
                        exportData[key] = localStorage[key];
                    }
                }
            }

            // Add settings
            exportData.settings = this.settings;
            exportData.exportDate = new Date().toISOString();
            exportData.app = 'Eyad AI';
            exportData.version = '1.0.0';

            // Create download
            const dataStr = JSON.stringify(exportData, null, 2);
            const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);

            const exportFileDefaultName = `eyad-ai-backup-${new Date().toISOString().split('T')[0]}.json`;

            const linkElement = document.createElement('a');
            linkElement.setAttribute('href', dataUri);
            linkElement.setAttribute('download', exportFileDefaultName);
            linkElement.click();

            showNotification('تم تصدير جميع البيانات بنجاح', 'success');

        } catch (error) {
            console.error('Export error:', error);
            showNotification('فشل تصدير البيانات', 'error');
        }
    }

    resetAllSettings() {
        if (confirm('هل تريد إعادة تعيين جميع الإعدادات إلى القيم الافتراضية؟ سيتم فقدان جميع التخصيصات.')) {
            // Clear all settings
            localStorage.removeItem('eyad_settings');

            // Clear theme preference
            localStorage.removeItem('theme');

            // Reset to defaults
            this.settings = {
                language: 'auto',
                aiLanguage: 'auto',
                autoCorrection: true,
                aiVoice: 'alloy',
                voiceSpeed: '1.0',
                autoPlayVoice: false,
                darkMode: false,
                primaryColor: '#4361ee',
                fontSize: 'medium'
            };

            // Apply defaults
            this.saveSettings();
            this.applySettingsToDOM();

            // Reset theme toggle
            const themeIcon = document.querySelector('.theme-toggle i');
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-moon');

            showNotification('تم إعادة تعيين جميع الإعدادات', 'success');
            this.calculateStorage();
        }
    }

    updateUI() {
        // Update color picker active state
        this.updateColorPicker();
    }
}

// Initialize settings app
const settingsApp = new SettingsApp();

// Global functions for HTML event handlers
function setColor(color) {
    settingsApp.setColor(color);
}

function testVoice() {
    settingsApp.testVoice();
}

function clearChatHistory() {
    settingsApp.clearChatHistory();
}

function clearDocumentsHistory() {
    settingsApp.clearDocumentsHistory();
}

function exportAllData() {
    settingsApp.exportAllData();
}

function resetAllSettings() {
    settingsApp.resetAllSettings();
}

// Recalculate storage periodically
setInterval(() => {
    settingsApp.calculateStorage();
}, 30000);