// Documents Application Logic
class DocumentsApp {
    constructor() {
        this.currentDocument = {
            title: '',
            content: '',
            type: 'general',
            language: 'ar',
            options: {
                includeImages: true,
                includeReferences: true,
                includeTableOfContents: false,
                includePageNumbers: true
            }
        };

        this.init();
    }

    init() {
        this.loadRecentDocuments();
        this.setupEventListeners();
        this.updateWordCount();
    }

    setupEventListeners() {
        // Load template when page loads
        window.addEventListener('load', () => {
            const urlParams = new URLSearchParams(window.location.search);
            const template = urlParams.get('template');
            if (template) {
                this.loadTemplate(template);
            }
        });

        // Auto-save document content
        const contentTextarea = document.getElementById('docContentTextarea');
        if (contentTextarea) {
            contentTextarea.addEventListener('input', () => {
                this.saveToLocalStorage();
            });
        }

        // Load saved document from localStorage
        this.loadFromLocalStorage();
    }

    updateWordCount() {
        const textarea = document.getElementById('docContentTextarea');
        const wordCountElement = document.getElementById('wordCount');

        if (!textarea || !wordCountElement) return;

        const text = textarea.value.trim();
        const words = text ? text.split(/\s+/).filter(word => word.length > 0) : [];
        const wordCount = words.length;

        wordCountElement.textContent = wordCount;

        // Update color based on limit
        if (wordCount > 3000) {
            wordCountElement.style.color = '#f72585';
            wordCountElement.innerHTML = `${wordCount} <i class="fas fa-exclamation-triangle"></i>`;
        } else if (wordCount > 2500) {
            wordCountElement.style.color = '#ff9800';
        } else {
            wordCountElement.style.color = 'inherit';
        }
    }

    async generateDocument() {
        // Get form values
        const title = document.getElementById('docTitleInput').value.trim();
        const content = document.getElementById('docContentTextarea').value.trim();
        const type = document.getElementById('docTypeSelect').value;
        const language = document.getElementById('docLanguageSelect').value;

        // Get options
        const options = {
            includeImages: document.getElementById('includeImages').checked,
            includeReferences: document.getElementById('includeReferences').checked,
            includeTableOfContents: document.getElementById('includeTableOfContents').checked,
            includePageNumbers: document.getElementById('includePageNumbers').checked
        };

        // Validation
        if (!title) {
            showNotification('يرجى إدخال عنوان المستند', 'error');
            return;
        }

        if (!content) {
            showNotification('يرجى إدخال محتوى المستند', 'error');
            return;
        }

        // Check word limit
        const wordCount = content.split(/\s+/).filter(word => word.length > 0).length;
        if (wordCount > 3000) {
            showNotification('المحتوى يتجاوز الحد الأقصى (3000 كلمة)', 'error');
            return;
        }

        try {
            showNotification('جاري إنشاء المستند...', 'info');

            const response = await fetch('/api/documents/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    title,
                    content,
                    type,
                    language,
                    includeImages: options.includeImages,
                    includeReferences: options.includeReferences,
                    includeTableOfContents: options.includeTableOfContents,
                    includePageNumbers: options.includePageNumbers
                })
            });

            const data = await response.json();

            if (data.success) {
                showNotification('تم إنشاء المستند بنجاح!', 'success');

                // Save to history
                this.saveToHistory({
                    title,
                    content: content.substring(0, 200) + '...',
                    filename: data.filename,
                    downloadUrl: data.downloadUrl,
                    size: data.size,
                    created: new Date().toISOString()
                });

                // Download the document
                const downloadLink = document.createElement('a');
                downloadLink.href = data.downloadUrl;
                downloadLink.download = `${title.replace(/\s+/g, '_')}.docx`;
                downloadLink.click();

                // Update recent documents
                this.loadRecentDocuments();

            } else {
                throw new Error(data.error || 'Failed to generate document');
            }

        } catch (error) {
            console.error('Document generation error:', error);
            showNotification('حدث خطأ في إنشاء المستند', 'error');
        }
    }

    async generateDocumentWithAI() {
        document.getElementById('aiModal').style.display = 'block';
    }

    closeAIModal() {
        document.getElementById('aiModal').style.display = 'none';
    }

    async generateAIContent() {
        const prompt = document.getElementById('aiPrompt').value.trim();
        const length = document.getElementById('aiLength').value;
        const difficulty = document.getElementById('aiDifficulty').value;

        if (!prompt) {
            showNotification('يرجى إدخال وصف المحتوى', 'error');
            return;
        }

        try {
            showNotification('جاري توليد المحتوى بالذكاء الاصطناعي...', 'info');

            // Get title from first line or use prompt
            const title = prompt.split('\n')[0].substring(0, 100);

            // Call AI API
            const response = await fetch('/api/ai/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: `أنشئ محتوى وثيقة حول: ${prompt}\n\nالمتطلبات:\n1. الطول: ${length} كلمة\n2. المستوى: ${difficulty}\n3. الصيغة: وثيقة منظمة مع عناوين وفقرات\n4. اللغة: العربية`,
                    conversationId: 'doc-gen-' + Date.now(),
                    language: 'ar'
                })
            });

            const data = await response.json();

            if (data.response) {
                // Update form with generated content
                document.getElementById('docTitleInput').value = title;
                document.getElementById('docContentTextarea').value = data.response;
                this.updateWordCount();

                showNotification('تم توليد المحتوى بنجاح!', 'success');
                this.closeAIModal();

                // Clear AI prompt
                document.getElementById('aiPrompt').value = '';

            } else {
                throw new Error('Failed to generate AI content');
            }

        } catch (error) {
            console.error('AI content generation error:', error);
            showNotification('حدث خطأ في توليد المحتوى', 'error');
        }
    }

    previewDocument() {
        const title = document.getElementById('docTitleInput').value.trim();
        const content = document.getElementById('docContentTextarea').value.trim();

        if (!title && !content) {
            showNotification('لا يوجد محتوى للمعاينة', 'warning');
            return;
        }

        const previewSection = document.getElementById('previewSection');
        const previewContent = document.getElementById('previewContent');

        let previewHTML = '';

        if (title) {
            previewHTML += `<h1 style="color: var(--primary-color); margin-bottom: 1rem;">${title}</h1>`;
        }

        if (content) {
            // Format content for preview
            const formattedContent = content
                .replace(/\n\s*\n/g, '</p><p>')
                .replace(/\n/g, '<br>')
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\*(.*?)\*/g, '<em>$1</em>');

            previewHTML += `<p style="line-height: 1.8;">${formattedContent}</p>`;
        }

        previewContent.innerHTML = previewHTML;
        previewSection.style.display = 'block';

        // Scroll to preview
        previewSection.scrollIntoView({ behavior: 'smooth' });
    }

    clearForm() {
        if (confirm('هل تريد مسح كل الحقول؟')) {
            document.getElementById('docTitleInput').value = '';
            document.getElementById('docContentTextarea').value = '';
            document.getElementById('docTypeSelect').value = 'general';
            document.getElementById('docLanguageSelect').value = 'ar';
            document.getElementById('includeImages').checked = true;
            document.getElementById('includeReferences').checked = true;
            document.getElementById('includeTableOfContents').checked = false;
            document.getElementById('includePageNumbers').checked = true;

            this.updateWordCount();

            // Hide preview
            document.getElementById('previewSection').style.display = 'none';

            // Clear localStorage
            localStorage.removeItem('eyad_draft_document');

            showNotification('تم مسح النموذج', 'success');
        }
    }

    loadTemplate(templateName) {
        const templates = {
            'research': {
                title: 'تقرير بحثي',
                content: `عنوان البحث: [أدخل عنوان البحث هنا]

الملخص التنفيذي
[اكتب ملخصاً مختصراً للبحث هنا]

المقدمة
[اكتب المقدمة هنا، وتتضمن مشكلة البحث، وأهميته، وأهدافه]

الإطار النظري
[اكتب الإطار النظري والدراسات السابقة هنا]

منهجية البحث
[صف منهجية البحث المستخدمة، والعينة، والأدوات، والإجراءات]

النتائج
[عرض النتائج هنا مع الجداول والأشكال التوضيحية]

المناقشة
[ناقش النتائج وربطها بالإطار النظري والدراسات السابقة]

الخاتمة والتوصيات
[اكتب الخاتمة والتوصيات المستخلصة من البحث]

المراجع
[أدرج قائمة المراجع هنا]`
            },
            'essay': {
                title: 'مقال أكاديمي',
                content: `عنوان المقال: [أدخل عنوان المقال هنا]

المقدمة
[ابدأ بمقدمة جذابة تعرض الموضوع وتطرح السؤال الرئيسي]

العرض
[قسم العرض إلى عدة فقرات، كل فكرة في فقرة منفصلة مع أدلة وبراهين]

الحجج والبراهين
[قدم الحجج المؤيدة والمعارضة مع التحليل النقدي]

التحليل
[حلل النقاط الرئيسية واربطها بالنظريات والمفاهيم]

الخاتمة
[لخص النقاط الرئيسية وأعطِ رأيك النهائي أو التوصيات]

المراجع
[أدرج المصادر المستخدمة]`
            },
            'business': {
                title: 'تقرير أعمال',
                content: `تقرير: [أدخل عنوان التقرير]

إلى: [اسم المدير أو القسم]
من: [اسمك أو قسمك]
التاريخ: [تاريخ التقرير]
الموضوع: [موضوع التقرير]

ملخص تنفيذي
[ملخص مختصر لأهم النقاط والتوصيات]

المقدمة
[خلفية عن الموضوع وأهميته]

التحليل
[تحليل الوضع الحالي، البيانات، والمعلومات المتاحة]

النتائج
[عرض النتائج الرئيسية]

التوصيات
[اقتراح الحلول والتوصيات العملية]

خطة التنفيذ
[الخطوات المطلوبة للتنفيذ، الجدول الزمني، والميزانية]

الخلاصة
[ملخص نهائي للتقرير]`
            },
            'letter': {
                title: 'رسالة رسمية',
                content: `[شعار المؤسسة - إذا كان متاحاً]

[اسم المرسل]
[عنوان المرسل]
[رقم الهاتف]
[البريد الإلكتروني]
[التاريخ]

[اسم المستلم]
[منصب المستلم]
[اسم المؤسسة]
[عنوان المؤسسة]

الموضوع: [موضوع الرسالة]

السيد/ة [اسم المستلم] المحترم/ة،

التحية والتقدير،

[محتوى الرسالة: اكتب فقرات الرسالة هنا، وتأكد من الوضوح والاختصار مع الإحاطة بجميع النقاط المطلوبة]

[توقيع]
[اسم المرسل]
[منصب المرسل]`
            },
            'lesson': {
                title: 'خطة درس',
                content: `خطة درس: [اسم المادة/الموضوع]

المعلومات الأساسية
- الصف: [رقم الصف]
- المادة: [اسم المادة]
- المدة: [مدة الحصة]
- التاريخ: [تاريخ الدرس]

الأهداف التعليمية
[اذكر الأهداف التي يسعى الدرس لتحقيقها]

المفاهيم الرئيسية
[اذكر المفاهيم والمصطلحات الرئيسية]

المواد والوسائل التعليمية
[اذكر المواد والوسائل المطلوبة]

الإجراءات
1. التمهيد (5 دقائق):
   [نشاط تمهيدي لجذب انتباه الطلاب]

2. العرض (20 دقيقة):
   [شرح المفاهيم الرئيسية مع أمثلة]

3. التطبيق (15 دقائق):
   [أنشطة تطبيقية وعمل جماعي]

4. التقويم (5 دقائق):
   [أسئلة وتقييم لفهم الطلاب]

5. الخاتمة (5 دقائق):
   [تلخيص وواجب منزلي]

التقييم
[كيف سيتم تقييم فهم الطلاب]

المراجع
[المصادر المستخدمة في إعداد الدرس]`
            },
            'summary': {
                title: 'ملخص دراسي',
                content: `ملخص: [اسم المادة/الكتاب]

الفصل/الوحدة: [رقم أو عنوان الفصل]

المفاهيم الرئيسية
1. [المفهوم الأول]
   - التعريف: [تعريف المفهوم]
   - الأمثلة: [أمثلة تطبيقية]
   - الأهمية: [أهمية المفهوم]

2. [المفهوم الثاني]
   - التعريف: [تعريف المفهوم]
   - الأمثلة: [أمثلة تطبيقية]
   - الأهمية: [أهمية المفهوم]

النقاط المهمة
- [النقطة الأولى]
- [النقطة الثانية]
- [النقطة الثالثة]

الصيغ والمعادلات (إذا وجدت)
1. [الصيغة الأولى]: [شرح الصيغة]
2. [الصيغة الثانية]: [شرح الصيغة]

الأسئلة المتوقعة
1. [سؤال متوقع مع إجابته]
2. [سؤال متوقع مع إجابته]

المراجع
- [المصدر الأول]
- [المصدر الثاني]`
            }
        };

        const template = templates[templateName];
        if (template) {
            document.getElementById('docTitleInput').value = template.title;
            document.getElementById('docContentTextarea').value = template.content;
            this.updateWordCount();
            showNotification(`تم تحميل قالب "${template.title}"`, 'success');
        }
    }

    saveToHistory(documentData) {
        const history = JSON.parse(localStorage.getItem('eyad_documents_history')) || [];

        // Add new document to beginning of array
        history.unshift({
            id: Date.now().toString(),
            ...documentData
        });

        // Keep only last 20 documents
        if (history.length > 20) {
            history.pop();
        }

        localStorage.setItem('eyad_documents_history', JSON.stringify(history));
        this.loadDocumentsHistory();
    }

    loadDocumentsHistory() {
        const historyContainer = document.getElementById('documentsHistory');
        const history = JSON.parse(localStorage.getItem('eyad_documents_history')) || [];

        if (history.length === 0) {
            historyContainer.innerHTML = `
                <div class="no-history">
                    <i class="fas fa-file-alt" style="font-size: 3rem; margin-bottom: 1rem;"></i>
                    <p>لا توجد مستندات سابقة</p>
                </div>
            `;
            return;
        }

        let historyHTML = '';

        history.forEach(doc => {
            const date = new Date(doc.created).toLocaleDateString('ar-EG', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });

            historyHTML += `
                <div class="history-card">
                    <div class="history-header">
                        <h4 class="history-title">${doc.title}</h4>
                        <div class="history-date">${date}</div>
                    </div>
                    <div class="history-content">${doc.content}</div>
                    <div class="history-actions">
                        <button onclick="documentsApp.downloadHistoryDocument('${doc.id}')" class="download-history-btn">
                            <i class="fas fa-download"></i> تحميل
                        </button>
                        <button onclick="documentsApp.deleteHistoryDocument('${doc.id}')" class="delete-history-btn">
                            <i class="fas fa-trash"></i> حذف
                        </button>
                    </div>
                </div>
            `;
        });

        historyContainer.innerHTML = historyHTML;
    }

    async downloadHistoryDocument(documentId) {
        const history = JSON.parse(localStorage.getItem('eyad_documents_history')) || [];
        const document = history.find(doc => doc.id === documentId);

        if (document && document.downloadUrl) {
            const downloadLink = document.createElement('a');
            downloadLink.href = document.downloadUrl;
            downloadLink.download = `${document.title.replace(/\s+/g, '_')}.docx`;
            downloadLink.click();
        } else {
            showNotification('تعذر العثور على المستند', 'error');
        }
    }

    deleteHistoryDocument(documentId) {
        if (confirm('هل تريد حذف هذا المستند من السجل؟')) {
            let history = JSON.parse(localStorage.getItem('eyad_documents_history')) || [];
            history = history.filter(doc => doc.id !== documentId);

            localStorage.setItem('eyad_documents_history', JSON.stringify(history));
            this.loadDocumentsHistory();
            this.loadRecentDocuments();

            showNotification('تم حذف المستند من السجل', 'success');
        }
    }

    loadRecentDocuments() {
        const recentContainer = document.getElementById('recentDocuments');
        const history = JSON.parse(localStorage.getItem('eyad_documents_history')) || [];
        const recent = history.slice(0, 5); // Last 5 documents

        if (recent.length === 0) {
            recentContainer.innerHTML = `
                <p style="color: var(--text-secondary); text-align: center; padding: 1rem;">
                    لا توجد مستندات حديثة
                </p>
            `;
            return;
        }

        let recentHTML = '<div style="display: flex; flex-direction: column; gap: 0.5rem;">';

        recent.forEach(doc => {
            const title = doc.title.length > 30 ? doc.title.substring(0, 30) + '...' : doc.title;

            recentHTML += `
                <div class="template-btn" onclick="documentsApp.loadDocumentFromHistory('${doc.id}')" style="justify-content: space-between;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <i class="fas fa-file-word"></i>
                        <span>${title}</span>
                    </div>
                    <small style="opacity: 0.7;">${new Date(doc.created).toLocaleDateString('ar-EG')}</small>
                </div>
            `;
        });

        recentHTML += '</div>';
        recentContainer.innerHTML = recentHTML;
    }

    loadDocumentFromHistory(documentId) {
        const history = JSON.parse(localStorage.getItem('eyad_documents_history')) || [];
        const document = history.find(doc => doc.id === documentId);

        if (document) {
            // Load document into form
            document.getElementById('docTitleInput').value = document.title;

            // Try to get full content from localStorage
            const draft = JSON.parse(localStorage.getItem('eyad_draft_document')) || {};
            if (draft.content && draft.title === document.title) {
                document.getElementById('docContentTextarea').value = draft.content;
            } else {
                document.getElementById('docContentTextarea').value = document.content;
            }

            this.updateWordCount();
            showNotification('تم تحميل المستند', 'success');
        }
    }

    saveToLocalStorage() {
        const draft = {
            title: document.getElementById('docTitleInput').value,
            content: document.getElementById('docContentTextarea').value,
            type: document.getElementById('docTypeSelect').value,
            language: document.getElementById('docLanguageSelect').value,
            options: {
                includeImages: document.getElementById('includeImages').checked,
                includeReferences: document.getElementById('includeReferences').checked,
                includeTableOfContents: document.getElementById('includeTableOfContents').checked,
                includePageNumbers: document.getElementById('includePageNumbers').checked
            },
            savedAt: new Date().toISOString()
        };

        localStorage.setItem('eyad_draft_document', JSON.stringify(draft));
    }

    loadFromLocalStorage() {
        const draft = JSON.parse(localStorage.getItem('eyad_draft_document'));

        if (draft) {
            document.getElementById('docTitleInput').value = draft.title || '';
            document.getElementById('docContentTextarea').value = draft.content || '';
            document.getElementById('docTypeSelect').value = draft.type || 'general';
            document.getElementById('docLanguageSelect').value = draft.language || 'ar';

            if (draft.options) {
                document.getElementById('includeImages').checked = draft.options.includeImages !== false;
                document.getElementById('includeReferences').checked = draft.options.includeReferences !== false;
                document.getElementById('includeTableOfContents').checked = draft.options.includeTableOfContents || false;
                document.getElementById('includePageNumbers').checked = draft.options.includePageNumbers !== false;
            }

            this.updateWordCount();

            // Show recovery message if draft exists
            if (draft.content && draft.savedAt) {
                const savedTime = new Date(draft.savedAt).toLocaleTimeString('ar-EG');
                console.log(`تم استعادة المسودة المحفوظة من الساعة ${savedTime}`);
            }
        }
    }
}

// Initialize documents app
const documentsApp = new DocumentsApp();

// Global functions for HTML event handlers
function updateWordCount() {
    documentsApp.updateWordCount();
}

function generateDocument() {
    documentsApp.generateDocument();
}

function generateDocumentWithAI() {
    documentsApp.generateDocumentWithAI();
}

function closeAIModal() {
    documentsApp.closeAIModal();
}

function generateAIContent() {
    documentsApp.generateAIContent();
}

function previewDocument() {
    documentsApp.previewDocument();
}

function clearForm() {
    documentsApp.clearForm();
}

function loadTemplate(templateName) {
    documentsApp.loadTemplate(templateName);
}

// Load history when page loads
window.addEventListener('load', () => {
    documentsApp.loadDocumentsHistory();
});

// Auto-save document every 30 seconds
setInterval(() => {
    documentsApp.saveToLocalStorage();
}, 30000);