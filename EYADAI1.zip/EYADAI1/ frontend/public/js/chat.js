// Chat Application Logic
class ChatApp {
    constructor() {
        this.conversationId = Date.now().toString();
        this.messages = [];
        this.mode = 'chat'; // chat, homework, correction
        this.isVoiceMode = false;
        this.textToSpeechEnabled = false;
        this.currentAudio = null;

        this.init();
    }

    init() {
        this.loadConversations();
        this.setupEventListeners();
        this.checkURLParams();
        this.updateUI();
    }

    setupEventListeners() {
        // Load saved conversations from localStorage
        window.addEventListener('load', () => {
            this.loadMessages();
        });
    }

    checkURLParams() {
        const urlParams = new URLSearchParams(window.location.search);
        const mode = urlParams.get('mode');

        if (mode === 'correction' || mode === 'homework') {
            this.setMode(mode);
        }
    }

    setMode(mode) {
        this.mode = mode;
        this.updateModeIndicator();

        // Add system message based on mode
        if (mode === 'homework') {
            this.addSystemMessage('أنا الآن في وضع المساعدة الدراسية. أرجو إرسال سؤالك الدراسي وسأشرحه خطوة بخطوة.');
        } else if (mode === 'correction') {
            this.addSystemMessage('أنا الآن في وضع تصحيح القواعد. أرجو إرسال النص الذي تريد تصحيحه وسأقوم بتصحيحه وتحسينه.');
        }
    }

    updateModeIndicator() {
        const indicator = document.getElementById('modeIndicator');
        const modeText = {
            'chat': 'وضع الدردشة العادية',
            'homework': 'وضع المساعدة الدراسية',
            'correction': 'وضع تصحيح القواعد'
        };

        const modeIcons = {
            'chat': 'fa-comments',
            'homework': 'fa-book',
            'correction': 'fa-spell-check'
        };

        indicator.innerHTML = `
            <i class="fas ${modeIcons[this.mode]}"></i>
            <span>${modeText[this.mode]}</span>
        `;
    }

    async sendMessage() {
        const input = document.getElementById('messageInput');
        const message = input.value.trim();

        if (!message) return;

        // Add user message to chat
        this.addMessage(message, 'user');
        input.value = '';

        // Show loading indicator
        this.showLoading();

        try {
            let endpoint = '/api/ai/chat';
            let requestBody = {
                message: message,
                conversationId: this.conversationId,
                language: this.getCurrentLanguage()
            };

            // Use different endpoints for different modes
            if (this.mode === 'homework') {
                endpoint = '/api/ai/homework';
                requestBody = {
                    question: message,
                    subject: 'عام',
                    gradeLevel: 'طالب'
                };
            } else if (this.mode === 'correction') {
                endpoint = '/api/ai/correct';
                requestBody = {
                    text: message,
                    language: this.getCurrentLanguage().includes('ar') ? 'arabic' : 'english'
                };
            }

            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestBody)
            });

            const data = await response.json();

            if (data.error) {
                throw new Error(data.error);
            }

            // Handle response based on mode
            let aiResponse = '';
            if (this.mode === 'homework') {
                aiResponse = data.explanation;
            } else if (this.mode === 'correction') {
                aiResponse = `النص المصحح:\n\n${data.corrected}\n\n--\nتم التصحيح والتحسين بنجاح!`;
            } else {
                aiResponse = data.response;
            }

            // Add AI response to chat
            this.addMessage(aiResponse, 'ai');

            // Save to localStorage
            this.saveMessages();

            // Convert to speech if enabled
            if (this.textToSpeechEnabled) {
                await this.convertToSpeech(aiResponse);
            }

        } catch (error) {
            console.error('Error sending message:', error);
            this.addMessage('عذراً، حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى.', 'ai');
            showNotification('حدث خطأ في إرسال الرسالة', 'error');
        } finally {
            this.hideLoading();
        }
    }

    addMessage(content, sender) {
        const chatMessages = document.getElementById('chatMessages');
        const messageId = `msg_${Date.now()}`;

        const messageDiv = document.createElement('div');
        messageDiv.className = `message-bubble ${sender}-message`;
        messageDiv.id = messageId;

        const avatar = sender === 'user' ? 'fas fa-user' : 'fas fa-robot';

        messageDiv.innerHTML = `
            <div class="message-avatar">
                <i class="${avatar}"></i>
            </div>
            <div class="message-content">
                <div class="message-text">${this.formatMessage(content)}</div>
                <div class="message-time">${this.getCurrentTime()}</div>
            </div>
            ${sender === 'ai' ? `
                <div class="message-actions">
                    <button onclick="chatApp.copyMessage('${messageId}')" title="نسخ">
                        <i class="fas fa-copy"></i>
                    </button>
                    <button onclick="chatApp.speakMessage('${messageId}')" title="استمع">
                        <i class="fas fa-volume-up"></i>
                    </button>
                </div>
            ` : ''}
        `;

        chatMessages.appendChild(messageDiv);

        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Store message
        this.messages.push({
            id: messageId,
            content: content,
            sender: sender,
            timestamp: new Date().toISOString()
        });
    }

    addSystemMessage(content) {
        const chatMessages = document.getElementById('chatMessages');

        const messageDiv = document.createElement('div');
        messageDiv.className = 'message-bubble system-message';

        messageDiv.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-info-circle"></i>
            </div>
            <div class="message-content">
                <div class="message-text">${content}</div>
            </div>
        `;

        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    formatMessage(content) {
        // Convert markdown-like formatting
        let formatted = content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>')
            .replace(/`([^`]+)`/g, '<code>$1</code>')
            .replace(/\n/g, '<br>');

        return formatted;
    }

    getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString('ar-EG', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }

    showLoading() {
        const chatMessages = document.getElementById('chatMessages');

        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'message-bubble ai-message loading';
        loadingDiv.id = 'loadingMessage';

        loadingDiv.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="message-content">
                <div class="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;

        chatMessages.appendChild(loadingDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Add typing indicator styles
        if (!document.getElementById('typingStyles')) {
            const style = document.createElement('style');
            style.id = 'typingStyles';
            style.textContent = `
                .typing-indicator {
                    display: flex;
                    gap: 4px;
                    padding: 10px 0;
                }
                .typing-indicator span {
                    width: 8px;
                    height: 8px;
                    background-color: #4361ee;
                    border-radius: 50%;
                    animation: typing 1.4s infinite ease-in-out;
                }
                .typing-indicator span:nth-child(1) { animation-delay: -0.32s; }
                .typing-indicator span:nth-child(2) { animation-delay: -0.16s; }
                @keyframes typing {
                    0%, 80%, 100% { transform: scale(0); }
                    40% { transform: scale(1); }
                }
            `;
            document.head.appendChild(style);
        }
    }

    hideLoading() {
        const loadingMessage = document.getElementById('loadingMessage');
        if (loadingMessage) {
            loadingMessage.remove();
        }
    }

    async convertToSpeech(text) {
        try {
            const response = await fetch('/api/speech/text-to-speech', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    text: text,
                    voice: document.getElementById('aiVoice')?.value || 'alloy',
                    language: this.getCurrentLanguage()
                })
            });

            const data = await response.json();

            if (data.success) {
                this.playAudio(data.fileUrl);
            }
        } catch (error) {
            console.error('TTS Error:', error);
        }
    }

    playAudio(url) {
        const audioPlayer = document.getElementById('audioPlayer');
        const responseAudio = document.getElementById('responseAudio');

        // Stop current audio if playing
        if (this.currentAudio) {
            this.currentAudio.pause();
        }

        responseAudio.src = url;
        audioPlayer.classList.remove('hidden');

        responseAudio.play().catch(e => {
            console.error('Audio play error:', e);
            showNotification('تعذر تشغيل الصوت', 'error');
        });

        this.currentAudio = responseAudio;
    }

    copyMessage(messageId) {
        const messageElement = document.getElementById(messageId);
        const messageText = messageElement.querySelector('.message-text').textContent;

        navigator.clipboard.writeText(messageText).then(() => {
            showNotification('تم نسخ النص', 'success');
        }).catch(err => {
            console.error('Copy failed:', err);
            showNotification('فشل النسخ', 'error');
        });
    }

    speakMessage(messageId) {
        const messageElement = document.getElementById(messageId);
        const messageText = messageElement.querySelector('.message-text').textContent;
        this.convertToSpeech(messageText);
    }

    newConversation() {
        this.conversationId = Date.now().toString();
        this.messages = [];

        // Clear chat UI
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.innerHTML = `
            <div class="welcome-message">
                <div class="message-bubble ai-message">
                    <div class="message-avatar">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="message-content">
                        <h4>مرحباً! أنا Eyad AI</h4>
                        <p>كيف يمكنني مساعدتك اليوم؟</p>
                    </div>
                </div>
            </div>
        `;

        // Update conversations list
        this.loadConversations();

        showNotification('بدأت محادثة جديدة', 'success');
    }

    clearChat() {
        if (confirm('هل تريد مسح جميع الرسائل في هذه المحادثة؟')) {
            this.messages = [];
            this.saveMessages();

            const chatMessages = document.getElementById('chatMessages');
            chatMessages.innerHTML = `
                <div class="welcome-message">
                    <div class="message-bubble ai-message">
                        <div class="message-avatar">
                            <i class="fas fa-robot"></i>
                        </div>
                        <div class="message-content">
                            <p>تم مسح المحادثة. ابدأ حديثاً جديداً!</p>
                        </div>
                    </div>
                </div>
            `;

            showNotification('تم مسح المحادثة', 'success');
        }
    }

    loadConversations() {
        const conversationsList = document.getElementById('conversationsList');
        const savedConversations = JSON.parse(localStorage.getItem('eyad_conversations')) || [];

        conversationsList.innerHTML = `
            <div class="conversation-item active" onclick="chatApp.loadConversation('new')">
                <i class="fas fa-plus"></i>
                <span>محادثة جديدة</span>
            </div>
        `;

        savedConversations.forEach((conv, index) => {
            const conversationItem = document.createElement('div');
            conversationItem.className = 'conversation-item';
            if (conv.id === this.conversationId) {
                conversationItem.classList.add('active');
            }

            const lastMessage = conv.messages[conv.messages.length - 1]?.content || 'بدون رسائل';
            const title = lastMessage.length > 30 ? lastMessage.substring(0, 30) + '...' : lastMessage;

            conversationItem.innerHTML = `
                <i class="fas fa-comment"></i>
                <span>${title}</span>
                <button class="delete-conversation" onclick="chatApp.deleteConversation('${conv.id}', event)">
                    <i class="fas fa-times"></i>
                </button>
            `;

            conversationItem.onclick = () => this.loadConversation(conv.id);
            conversationsList.appendChild(conversationItem);
        });
    }

    loadConversation(id) {
        if (id === 'new') {
            this.newConversation();
            return;
        }

        const savedConversations = JSON.parse(localStorage.getItem('eyad_conversations')) || [];
        const conversation = savedConversations.find(c => c.id === id);

        if (conversation) {
            this.conversationId = id;
            this.messages = conversation.messages;
            this.renderMessages();
            this.loadConversations();
            showNotification('تم تحميل المحادثة', 'success');
        }
    }

    deleteConversation(id, event) {
        event.stopPropagation();

        if (confirm('هل تريد حذف هذه المحادثة؟')) {
            let savedConversations = JSON.parse(localStorage.getItem('eyad_conversations')) || [];
            savedConversations = savedConversations.filter(c => c.id !== id);

            localStorage.setItem('eyad_conversations', JSON.stringify(savedConversations));

            if (this.conversationId === id) {
                this.newConversation();
            }

            this.loadConversations();
            showNotification('تم حذف المحادثة', 'success');
        }
    }

    saveMessages() {
        const savedConversations = JSON.parse(localStorage.getItem('eyad_conversations')) || [];
        const existingIndex = savedConversations.findIndex(c => c.id === this.conversationId);

        const conversationData = {
            id: this.conversationId,
            messages: this.messages,
            mode: this.mode,
            lastUpdated: new Date().toISOString()
        };

        if (existingIndex > -1) {
            savedConversations[existingIndex] = conversationData;
        } else if (this.messages.length > 0) {
            savedConversations.push(conversationData);
        }

        localStorage.setItem('eyad_conversations', JSON.stringify(savedConversations));
    }

    loadMessages() {
        const savedConversations = JSON.parse(localStorage.getItem('eyad_conversations')) || [];
        const conversation = savedConversations.find(c => c.id === this.conversationId);

        if (conversation) {
            this.messages = conversation.messages;
            this.mode = conversation.mode || 'chat';
            this.renderMessages();
        }
    }

    renderMessages() {
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.innerHTML = '';

        if (this.messages.length === 0) {
            chatMessages.innerHTML = `
                <div class="welcome-message">
                    <div class="message-bubble ai-message">
                        <div class="message-avatar">
                            <i class="fas fa-robot"></i>
                        </div>
                        <div class="message-content">
                            <h4>مرحباً! أنا Eyad AI</h4>
                            <p>كيف يمكنني مساعدتك اليوم؟</p>
                        </div>
                    </div>
                </div>
            `;
        } else {
            this.messages.forEach(msg => {
                this.addMessage(msg.content, msg.sender);
            });
        }
    }

    getCurrentLanguage() {
        const savedLanguage = localStorage.getItem('eyad_language') || 'auto';
        if (savedLanguage === 'auto') {
            return navigator.language || 'ar-EG';
        }
        return savedLanguage;
    }

    updateUI() {
        this.updateModeIndicator();

        // Update voice controls visibility
        const voiceControls = document.getElementById('voiceControls');
        if (this.isVoiceMode) {
            voiceControls.classList.remove('hidden');
        } else {
            voiceControls.classList.add('hidden');
        }
    }
}

// Initialize chat app
const chatApp = new ChatApp();

// Global functions for HTML event handlers
function handleKeydown(event) {
    if (event.ctrlKey && event.key === 'Enter') {
        event.preventDefault();
        chatApp.sendMessage();
    }
}

function setMode(mode) {
    chatApp.setMode(mode);
}

function toggleTextToSpeech() {
    chatApp.textToSpeechEnabled = !chatApp.textToSpeechEnabled;
    const icon = document.querySelector('.input-tool .fa-volume-up');

    if (chatApp.textToSpeechEnabled) {
        icon.classList.add('active');
        showNotification('تم تفعيل تحويل النص إلى كلام', 'success');
    } else {
        icon.classList.remove('active');
        showNotification('تم إيقاف تحويل النص إلى كلام', 'info');
    }
}

function toggleVoiceMode() {
    document.getElementById('voiceModal').style.display = 'block';
}

function closeVoiceModal() {
    document.getElementById('voiceModal').style.display = 'none';
}

function attachFile() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.txt,.pdf,.doc,.docx,.jpg,.png';

    input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        if (file.size > 10 * 1024 * 1024) { // 10MB
            showNotification('الملف كبير جداً. الحد الأقصى 10MB', 'error');
            return;
        }

        showNotification('جاري معالجة الملف...', 'info');

        // For text files, read and send as message
        if (file.type.startsWith('text/') || file.name.endsWith('.txt')) {
            const reader = new FileReader();
            reader.onload = (event) => {
                const text = event.target.result;
                document.getElementById('messageInput').value = text;
                showNotification('تم تحميل النص من الملف', 'success');
            };
            reader.readAsText(file);
        } else {
            showNotification('هذا النوع من الملفات غير مدعوم حالياً', 'warning');
        }
    };

    input.click();
}

function downloadAudio() {
    const audio = document.getElementById('responseAudio');
    const source = audio.src;

    if (source) {
        const link = document.createElement('a');
        link.href = source;
        link.download = `eyad-ai-${Date.now()}.mp3`;
        link.click();
    }
}

// Add chat-specific CSS
const chatStyles = document.createElement('style');
chatStyles.textContent = `
    .chat-container {
        display: flex;
        height: calc(100vh - 70px);
    }

    .chat-sidebar {
        width: 280px;
        background-color: var(--bg-secondary);
        border-left: 1px solid var(--border-color);
        display: flex;
        flex-direction: column;
        overflow-y: auto;
    }

    .sidebar-header {
        padding: 1.5rem;
        border-bottom: 1px solid var(--border-color);
    }

    .sidebar-header h3 {
        margin-bottom: 1rem;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .conversations-list {
        flex: 1;
        overflow-y: auto;
        padding: 1rem;
    }

    .conversation-item {
        padding: 0.75rem 1rem;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 0.5rem;
        transition: var(--transition);
        position: relative;
    }

    .conversation-item:hover {
        background-color: var(--bg-card);
    }

    .conversation-item.active {
        background-color: var(--primary-color);
        color: white;
    }

    .delete-conversation {
        position: absolute;
        left: 10px;
        background: none;
        border: none;
        color: inherit;
        cursor: pointer;
        opacity: 0.7;
        padding: 4px;
    }

    .delete-conversation:hover {
        opacity: 1;
    }

    .sidebar-tools {
        padding: 1.5rem;
        border-top: 1px solid var(--border-color);
    }

    .tools-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 0.75rem;
        margin-top: 1rem;
    }

    .tool-btn {
        padding: 0.75rem;
        background-color: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 8px;
        cursor: pointer;
        text-align: right;
        display: flex;
        align-items: center;
        gap: 10px;
        transition: var(--transition);
    }

    .tool-btn:hover {
        background-color: var(--primary-color);
        color: white;
        border-color: var(--primary-color);
    }

    .chat-main {
        flex: 1;
        display: flex;
        flex-direction: column;
        background-color: var(--bg-primary);
    }

    .chat-header {
        padding: 1rem 1.5rem;
        border-bottom: 1px solid var(--border-color);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .chat-mode-indicator {
        display: flex;
        align-items: center;
        gap: 10px;
        background-color: var(--bg-secondary);
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.9rem;
    }

    .voice-controls {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .voice-btn {
        padding: 0.5rem 1rem;
        background-color: var(--accent-color);
        color: white;
        border: none;
        border-radius: 20px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .voice-status {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 0.9rem;
        color: var(--text-secondary);
    }

    .voice-status i {
        color: #4CAF50;
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
    }

    .chat-messages {
        flex: 1;
        overflow-y: auto;
        padding: 1.5rem;
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }

    .message-bubble {
        display: flex;
        gap: 1rem;
        max-width: 80%;
        animation: fadeIn 0.3s ease-out;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .user-message {
        align-self: flex-end;
        flex-direction: row-reverse;
    }

    .ai-message {
        align-self: flex-start;
    }

    .message-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: var(--bg-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .user-message .message-avatar {
        background-color: var(--primary-color);
        color: white;
    }

    .ai-message .message-avatar {
        background-color: var(--accent-color);
        color: white;
    }

    .message-content {
        background-color: var(--bg-card);
        padding: 1rem 1.5rem;
        border-radius: 18px;
        flex: 1;
        box-shadow: var(--shadow);
    }

    .user-message .message-content {
        background-color: var(--primary-color);
        color: white;
        border-bottom-right-radius: 4px;
    }

    .ai-message .message-content {
        border-bottom-left-radius: 4px;
    }

    .message-text {
        line-height: 1.6;
        margin-bottom: 0.5rem;
    }

    .message-text pre {
        background-color: var(--bg-secondary);
        padding: 1rem;
        border-radius: 8px;
        overflow-x: auto;
        margin: 1rem 0;
    }

    .message-text code {
        background-color: var(--bg-secondary);
        padding: 2px 6px;
        border-radius: 4px;
        font-family: 'Courier New', monospace;
    }

    .message-time {
        font-size: 0.8rem;
        opacity: 0.7;
        text-align: left;
    }

    .user-message .message-time {
        text-align: right;
        color: rgba(255,255,255,0.8);
    }

    .message-actions {
        display: flex;
        flex-direction: column;
        gap: 5px;
        opacity: 0;
        transition: opacity 0.3s;
    }

    .ai-message:hover .message-actions {
        opacity: 1;
    }

    .message-actions button {
        background: none;
        border: 1px solid var(--border-color);
        border-radius: 4px;
        padding: 4px 8px;
        cursor: pointer;
        color: var(--text-secondary);
    }

    .message-actions button:hover {
        background-color: var(--bg-secondary);
        color: var(--primary-color);
    }

    .chat-input-area {
        border-top: 1px solid var(--border-color);
        padding: 1.5rem;
    }

    .input-tools {
        display: flex;
        gap: 0.5rem;
        margin-bottom: 1rem;
    }

    .input-tool {
        background: none;
        border: 1px solid var(--border-color);
        border-radius: 50%;
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: var(--text-secondary);
        transition: var(--transition);
    }

    .input-tool:hover {
        background-color: var(--bg-secondary);
        color: var(--primary-color);
    }

    .input-tool.active {
        background-color: var(--primary-color);
        color: white;
        border-color: var(--primary-color);
    }

    .input-container {
        display: flex;
        gap: 1rem;
        align-items: flex-end;
    }

    #messageInput {
        flex: 1;
        padding: 1rem;
        border: 1px solid var(--border-color);
        border-radius: 12px;
        font-family: inherit;
        font-size: 1rem;
        resize: none;
        background-color: var(--bg-card);
        color: var(--text-primary);
        transition: var(--transition);
    }

    #messageInput:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
    }

    .send-btn {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background-color: var(--primary-color);
        color: white;
        border: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: var(--transition);
        flex-shrink: 0;
    }

    .send-btn:hover {
        background-color: var(--secondary-color);
        transform: scale(1.05);
    }

    .audio-player {
        margin-top: 1rem;
        padding: 1rem;
        background-color: var(--bg-secondary);
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .audio-player audio {
        flex: 1;
    }

    .download-btn {
        background: none;
        border: 1px solid var(--border-color);
        border-radius: 50%;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: var(--text-secondary);
    }

    .download-btn:hover {
        background-color: var(--bg-card);
        color: var(--primary-color);
    }

    .hidden {
        display: none !important;
    }

    .voice-modal-content {
        padding: 1rem 0;
    }

    .voice-instructions {
        background-color: var(--bg-secondary);
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
    }

    .voice-recording {
        text-align: center;
        padding: 2rem;
        background-color: var(--bg-secondary);
        border-radius: 12px;
        margin-bottom: 1.5rem;
    }

    .recording-visualizer {
        display: flex;
        justify-content: center;
        gap: 4px;
        height: 40px;
        margin-bottom: 1rem;
    }

    .visualizer-bar {
        width: 6px;
        background-color: var(--primary-color);
        border-radius: 3px;
        animation: visualize 1s infinite ease-in-out;
    }

    .visualizer-bar:nth-child(1) { animation-delay: 0.1s; }
    .visualizer-bar:nth-child(2) { animation-delay: 0.2s; }
    .visualizer-bar:nth-child(3) { animation-delay: 0.3s; }
    .visualizer-bar:nth-child(4) { animation-delay: 0.4s; }
    .visualizer-bar:nth-child(5) { animation-delay: 0.5s; }

    @keyframes visualize {
        0%, 100% { height: 10px; }
        50% { height: 40px; }
    }

    .recording-text {
        font-size: 1.1rem;
        font-weight: bold;
    }

    .voice-settings {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.5rem;
        margin-bottom: 1.5rem;
    }

    .setting-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .setting-group label {
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .setting-group select {
        padding: 0.75rem;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        background-color: var(--bg-card);
        color: var(--text-primary);
    }

    .btn-small {
        padding: 0.5rem 1rem;
        font-size: 0.9rem;
    }

    @media (max-width: 768px) {
        .chat-container {
            flex-direction: column;
        }

        .chat-sidebar {
            width: 100%;
            height: 200px;
            border-left: none;
            border-bottom: 1px solid var(--border-color);
        }

        .conversations-list {
            display: flex;
            overflow-x: auto;
            padding: 0.5rem;
        }

        .conversation-item {
            flex-shrink: 0;
            min-width: 150px;
        }

        .message-bubble {
            max-width: 90%;
        }

        .voice-settings {
            grid-template-columns: 1fr;
        }
    }
`;
document.head.appendChild(chatStyles);