// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = themeToggle.querySelector('i');

// Check for saved theme or prefer-color-scheme
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
const currentTheme = localStorage.getItem('theme');

if (currentTheme === 'dark' || (!currentTheme && prefersDark.matches)) {
    document.body.classList.add('dark-mode');
    themeIcon.classList.remove('fa-moon');
    themeIcon.classList.add('fa-sun');
}

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');

    if (document.body.classList.contains('dark-mode')) {
        localStorage.setItem('theme', 'dark');
        themeIcon.classList.remove('fa-moon');
        themeIcon.classList.add('fa-sun');
    } else {
        localStorage.setItem('theme', 'light');
        themeIcon.classList.remove('fa-sun');
        themeIcon.classList.add('fa-moon');
    }
});

// Modal Functions
function openDocumentModal() {
    document.getElementById('documentModal').style.display = 'block';
}

function closeDocumentModal() {
    document.getElementById('documentModal').style.display = 'none';
}

function openCorrectionModal() {
    showNotification('سيتم توجيهك إلى صفحة التصحيح', 'info');
    setTimeout(() => {
        window.location.href = 'chat.html?mode=correction';
    }, 1500);
}

function openHomeworkModal() {
    showNotification('سيتم توجيهك إلى صفحة المساعدة الدراسية', 'info');
    setTimeout(() => {
        window.location.href = 'chat.html?mode=homework';
    }, 1500);
}

// Generate Quick Document
async function generateQuickDocument() {
    const title = document.getElementById('docTitle').value;
    const content = document.getElementById('docContent').value;

    if (!title || !content) {
        showNotification('يرجى ملء جميع الحقول', 'error');
        return;
    }

    try {
        showNotification('جاري إنشاء المستند...', 'info');

        const response = await fetch('/api/documents/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                title,
                content,
                language: 'ar'
            })
        });

        const data = await response.json();

        if (data.success) {
            showNotification('تم إنشاء المستند بنجاح!', 'success');

            // Create download link
            const downloadLink = document.createElement('a');
            downloadLink.href = data.downloadUrl;
            downloadLink.download = data.filename;
            downloadLink.click();

            closeDocumentModal();

            // Clear form
            document.getElementById('docTitle').value = '';
            document.getElementById('docContent').value = '';
        } else {
            throw new Error(data.error || 'Failed to generate document');
        }
    } catch (error) {
        console.error('Document generation error:', error);
        showNotification('حدث خطأ في إنشاء المستند', 'error');
    }
}

// Notification System
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());

    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;

    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 1rem;
        border-radius: 5px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        max-width: 400px;
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
    `;

    document.body.appendChild(notification);

    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

function getNotificationIcon(type) {
    switch(type) {
        case 'success': return 'fa-check-circle';
        case 'error': return 'fa-exclamation-circle';
        case 'warning': return 'fa-exclamation-triangle';
        default: return 'fa-info-circle';
    }
}

function getNotificationColor(type) {
    switch(type) {
        case 'success': return '#4CAF50';
        case 'error': return '#F44336';
        case 'warning': return '#FF9800';
        default: return '#2196F3';
    }
}

// Add CSS for animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    .notification-content {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .notification-close {
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        padding: 0;
        font-size: 1rem;
    }
`;
document.head.appendChild(style);

// Close modal when clicking outside
window.addEventListener('click', (event) => {
    const modal = document.getElementById('documentModal');
    if (event.target === modal) {
        closeDocumentModal();
    }
});

// API Health Check
async function checkAPIHealth() {
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        console.log('API Health:', data);

        if (data.status !== 'healthy') {
            showNotification('قد تواجه مشاكل في الاتصال بالخادم', 'warning');
        }
    } catch (error) {
        console.error('API Health check failed:', error);
        showNotification('تعذر الاتصال بالخادم', 'error');
    }
}

// Check API health on page load
window.addEventListener('load', checkAPIHealth);

// Keyboard shortcuts
document.addEventListener('keydown', (event) => {
    // Ctrl/Cmd + / to focus search
    if ((event.ctrlKey || event.metaKey) && event.key === '/') {
        event.preventDefault();
        const searchInput = document.querySelector('input[type="search"]');
        if (searchInput) {
            searchInput.focus();
        }
    }

    // Escape to close modals
    if (event.key === 'Escape') {
        closeDocumentModal();
    }
});