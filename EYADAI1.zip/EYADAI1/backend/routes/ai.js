const express = require('express');
const router = express.Router();
const OpenAI = require('openai');

// Initialize OpenAI with API key
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Store conversation history (in production, use database)
const conversations = new Map();

// Chat completion endpoint
router.post('/chat', async (req, res) => {
  try {
    const { message, conversationId, language = 'auto' } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    // Get or create conversation history
    if (!conversationId) {
      const newId = Date.now().toString();
      conversations.set(newId, []);
    }

    const conversationHistory = conversations.get(conversationId) || [];

    // Detect language if auto
    let systemPrompt = "You are Eyad AI, a helpful AI assistant that provides educational support, productivity tools, and communication assistance. Be friendly, clear, and informative.";

    if (language === 'ar-EG' || language === 'ar') {
      systemPrompt = "أنت Eyad AI، مساعد ذكي مفيد يقدم دعماً تعليمياً وأدوات إنتاجية ومساعدة في الاتصال. كن ودوداً، واضحاً، وغني بالمعلومات. تحدث باللهجة المصرية عندما يكون ذلك مناسباً.";
    }

    // Prepare messages
    const messages = [
      { role: 'system', content: systemPrompt },
      ...conversationHistory.slice(-10), // Last 10 messages for context
      { role: 'user', content: message }
    ];

    // Call OpenAI API
    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: messages,
      temperature: 0.7,
      max_tokens: 1500,
    });

    const aiResponse = completion.choices[0].message.content;

    // Update conversation history
    conversationHistory.push(
      { role: 'user', content: message },
      { role: 'assistant', content: aiResponse }
    );
    conversations.set(conversationId, conversationHistory);

    res.json({
      response: aiResponse,
      conversationId: conversationId || Date.now().toString(),
      tokens: completion.usage
    });

  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ 
      error: 'Failed to process chat request',
      details: error.message 
    });
  }
});

// Homework assistance endpoint
router.post('/homework', async (req, res) => {
  try {
    const { subject, question, gradeLevel } = req.body;

    if (!question) {
      return res.status(400).json({ error: 'Question is required' });
    }

    const systemPrompt = `You are an expert ${subject} tutor. Explain the solution step by step in a clear, educational manner suitable for a ${gradeLevel || 'student'}. Break down complex concepts and provide examples if needed.`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: question }
      ],
      temperature: 0.5,
      max_tokens: 2000,
    });

    const explanation = completion.choices[0].message.content;

    res.json({
      subject,
      question,
      explanation,
      steps: explanation.split('\n\n').filter(step => step.trim()),
      references: []
    });

  } catch (error) {
    console.error('Homework error:', error);
    res.status(500).json({ 
      error: 'Failed to process homework request',
      details: error.message 
    });
  }
});

// Grammar correction endpoint
router.post('/correct', async (req, res) => {
  try {
    const { text, language = 'english' } = req.body;

    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }

    const systemPrompt = language.toLowerCase().includes('arabic') 
      ? 'أنت خبير في اللغة العربية. صحح الأخطاء النحوية والإملائية وحسن الأسلوب مع شرح الأخطاء وتقديم البدائل الأفضل.'
      : 'You are an English language expert. Correct grammar, spelling, and improve writing style with explanations of the corrections.';

    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Please correct and improve this text:\n\n${text}` }
      ],
      temperature: 0.3,
      max_tokens: 2000,
    });

    const correctedText = completion.choices[0].message.content;

    res.json({
      original: text,
      corrected: correctedText,
      language,
      improvements: []
    });

  } catch (error) {
    console.error('Correction error:', error);
    res.status(500).json({ 
      error: 'Failed to process correction request',
      details: error.message 
    });
  }
});

// Clear conversation
router.delete('/conversation/:id', (req, res) => {
  const { id } = req.params;
  conversations.delete(id);
  res.json({ success: true, message: 'Conversation cleared' });
});

module.exports = router;