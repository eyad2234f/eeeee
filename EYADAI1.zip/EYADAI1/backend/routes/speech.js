const express = require('express');
const router = express.Router();
const fs = require('fs-extra');
const path = require('path');
const OpenAI = require('openai');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Text-to-Speech endpoint
router.post('/text-to-speech', async (req, res) => {
  try {
    const { text, voice = 'alloy', language = 'en' } = req.body;

    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }

    // Use OpenAI's TTS API
    const mp3 = await openai.audio.speech.create({
      model: "tts-1",
      voice: voice,
      input: text,
      response_format: "mp3",
      speed: 1.0,
    });

    // Generate unique filename
    const filename = `speech-${Date.now()}.mp3`;
    const filePath = path.join(__dirname, '../temp', filename);

    // Convert response to buffer and save
    const buffer = Buffer.from(await mp3.arrayBuffer());
    await fs.writeFile(filePath, buffer);

    const fileUrl = `/temp/${filename}`;

    res.json({
      success: true,
      filename,
      fileUrl: `${req.protocol}://${req.get('host')}${fileUrl}`,
      text,
      voice,
      language,
      size: buffer.length,
      duration: Math.ceil(buffer.length / 16000) // Rough estimate
    });

  } catch (error) {
    console.error('TTS error:', error);
    res.status(500).json({ 
      error: 'Failed to generate speech',
      details: error.message 
    });
  }
});

// Speech-to-Text endpoint
router.post('/speech-to-text', async (req, res) => {
  try {
    const { audio, language = 'en' } = req.body;

    if (!audio) {
      return res.status(400).json({ error: 'Audio data is required' });
    }

    // Convert base64 audio to buffer
    const audioBuffer = Buffer.from(audio, 'base64');

    // Generate unique filename
    const filename = `upload-${Date.now()}.webm`;
    const filePath = path.join(__dirname, '../temp', filename);

    // Save temporary file
    await fs.writeFile(filePath, audioBuffer);

    // Use OpenAI's Whisper API
    const transcription = await openai.audio.transcriptions.create({
      file: fs.createReadStream(filePath),
      model: "whisper-1",
      language: language === 'ar' ? 'ar' : 'en',
      response_format: "text",
    });

    // Clean up temp file
    await fs.remove(filePath);

    res.json({
      success: true,
      text: transcription,
      language,
      filename
    });

  } catch (error) {
    console.error('STT error:', error);
    res.status(500).json({ 
      error: 'Failed to transcribe speech',
      details: error.message 
    });
  }
});

// Get available voices
router.get('/voices', (req, res) => {
  const voices = [
    { id: 'alloy', name: 'Alloy', language: 'en', gender: 'neutral' },
    { id: 'echo', name: 'Echo', language: 'en', gender: 'male' },
    { id: 'fable', name: 'Fable', language: 'en', gender: 'female' },
    { id: 'onyx', name: 'Onyx', language: 'en', gender: 'male' },
    { id: 'nova', name: 'Nova', language: 'en', gender: 'female' },
    { id: 'shimmer', name: 'Shimmer', language: 'en', gender: 'female' },
  ];

  res.json({
    success: true,
    voices,
    defaultVoice: 'alloy'
  });
});

// Get audio file
router.get('/audio/:filename', (req, res) => {
  try {
    const { filename } = req.params;
    const filePath = path.join(__dirname, '../temp', filename);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'Audio file not found' });
    }

    res.setHeader('Content-Type', 'audio/mpeg');
    res.sendFile(filePath);

  } catch (error) {
    console.error('Audio serve error:', error);
    res.status(500).json({ 
      error: 'Failed to serve audio file',
      details: error.message 
    });
  }
});

module.exports = router;